Fixes #issue-number

## What does this PR do?

## Checklist

- [ ] I have read the [Contributing Guide](https://webtui.ironclad.sh/contributing/contributing)
- [ ] My Pull Request abides by the [Style Guide](https://webtui.ironclad.sh/contributing/style-guide)
