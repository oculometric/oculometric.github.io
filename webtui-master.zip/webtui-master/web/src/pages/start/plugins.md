---
layout: '@/layouts/Doc.astro'
title: Plugins
order: -2
---

Plugins are external stylesheets that are designed to work alongside `@webtui/css`

## Official Plugins

- [Nerd Font Plugin](/plugins/plugin-nf)

### Themes

- [Catppuccin Theme](/plugins/theme-catppuccin)
- [Nord Theme](/plugins/theme-nord)
- [Gruvbox Theme](/plugins/theme-gruvbox)
- [Vitesse Theme](/plugins/theme-vitesse)
  [Everforest Theme](/plugins/theme-everforest)

## Community Plugins

None yet, be the first!
