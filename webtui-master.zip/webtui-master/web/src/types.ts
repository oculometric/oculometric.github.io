export interface Project {
    title: string
    url: string
    imageUrl: string
    source?: string
    tags?: string[]
}
