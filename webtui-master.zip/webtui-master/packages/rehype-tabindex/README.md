# @webtui/rehype-tabindex

Internal plugin for the WebTUI documentation

Adds `tabindex="0"` to some markdown block elements for vim-like navigation

Wraps images in div elements with a figcaption so they can be tabbed to
